package kr.co.softcampus.beans;

public class TestBean4 {
	
	public TestBean4() {
		System.out.println("TestBean4의 생성자");
	}
}
