package kr.co.softcampus.beans;

public class DataBean3 {

}
