package kr.co.softcampus.beans;

public class HelloWorldKo {
	
	public void sayHello() {
		System.out.println("안녕하세요");
	}
}
