package kr.co.softcampus.beans;

public class TestBean1 {

}
