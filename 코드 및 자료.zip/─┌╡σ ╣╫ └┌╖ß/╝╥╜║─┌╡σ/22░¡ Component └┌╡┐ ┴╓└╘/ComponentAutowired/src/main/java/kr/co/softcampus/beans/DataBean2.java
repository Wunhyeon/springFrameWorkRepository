package kr.co.softcampus.beans;

import org.springframework.stereotype.Component;

@Component("obj2")
public class DataBean2 {

}
