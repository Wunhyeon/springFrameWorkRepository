package kr.co.softcampus.beans2;

public class TestBean1 {
	
	public void method1() {
		System.out.println("beans2.TestBean1.method1()");
	}
}
