package kr.co.softcampus.beans3;

import org.springframework.stereotype.Component;

@Component
public class TestBean5 {

}
