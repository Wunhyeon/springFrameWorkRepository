package kr.co.softcampus.beans;

public class TestBean {
	
	public int method1() {
		System.out.println("method1 호출");
		
		//int a1 = 10 / 0;
		
		return 100;
	}
}
