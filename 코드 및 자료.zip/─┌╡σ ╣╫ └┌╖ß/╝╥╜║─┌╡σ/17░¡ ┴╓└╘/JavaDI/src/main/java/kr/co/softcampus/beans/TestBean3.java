package kr.co.softcampus.beans;

public class TestBean3 {
	private DataBean3 data1;
	private DataBean3 data2;
	
	public DataBean3 getData1() {
		return data1;
	}
	public void setData1(DataBean3 data1) {
		this.data1 = data1;
	}
	public DataBean3 getData2() {
		return data2;
	}
	public void setData2(DataBean3 data2) {
		this.data2 = data2;
	}
	
	
}
