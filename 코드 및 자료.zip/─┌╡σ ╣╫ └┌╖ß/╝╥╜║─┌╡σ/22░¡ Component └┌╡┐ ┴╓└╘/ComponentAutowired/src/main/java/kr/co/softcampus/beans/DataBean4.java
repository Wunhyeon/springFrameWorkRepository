package kr.co.softcampus.beans;

import org.springframework.stereotype.Component;

@Component
public class DataBean4 {

}
