package kr.co.softcampus.beans2;

import org.springframework.stereotype.Component;

@Component("bean4")
public class TestBean4 {

}
