package kr.co.softcampus.beans;

public class TestBean3 {
	
	public TestBean3() {
		System.out.println("TestBean3의 생성자");
	}
}
