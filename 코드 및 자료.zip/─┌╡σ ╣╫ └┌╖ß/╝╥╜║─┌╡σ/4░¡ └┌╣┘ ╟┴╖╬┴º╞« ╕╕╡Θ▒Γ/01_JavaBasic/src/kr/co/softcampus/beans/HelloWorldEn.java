package kr.co.softcampus.beans;

public class HelloWorldEn {
	
	public void sayHello() {
		System.out.println("HI~~~");
	}
}
